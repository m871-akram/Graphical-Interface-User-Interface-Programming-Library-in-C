file(REMOVE_RECURSE
  "CMakeFiles/hello_world.dir/tests/hello_world.c.o"
  "CMakeFiles/hello_world.dir/tests/hello_world.c.o.d"
  "hello_world"
  "hello_world.pdb"
)

# Per-language clean rules from dependency scanning.
foreach(lang C)
  include(CMakeFiles/hello_world.dir/cmake_clean_${lang}.cmake OPTIONAL)
endforeach()
